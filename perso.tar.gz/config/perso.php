<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Custom config
    |--------------------------------------------------------------------------
    |
    | These auto-documented values are proper to each school
    | Most of them should be edited in .env instead of here
    |
    */

    'ecole' => env('ECOLE', 'School name'),
    'articleecole' => env('ARTICLE_ECOLE', "le /la /l'/les "),
    'fase_ecole' => env('FASE_ECOLE', "01234"),
    // School logotype (small size and paysage)
    'logo_ecole_xs' => env('LOGO_ECOLE_XS', '%public%/path/to/image'),
    // School logotype (medium size)
    'logo_ecole_s' => env('LOGO_ECOLE_S', '%public%/path/to/image'),
    'lib_ecole' => env('LIB_ECOLE', 'School full name'),
    // Letter header for the school (for e-mails and printing)
    'entete_ecole' => env('ENTETE_ECOLE', '/perso/img/entete_ecole.png'),
    // User chart (legal) UNUSED @TODO remove in next version
    'charte_util' => env('CHARTE_UTIL', '%public%/path/to/userchart'),
    
    // 16 bits hex crypto key (CHANGE ME!!)
    'cle' => env('CLE', '8a45fd139119dd12d41f94bf1d19a49d'),
    
    // Password to register as teacher
    'profcode' => env('PROFCODE', "Yes, I'm teaching in this school"),
    
    // Password to register as educator
    'educcode' => env('EDUCCODE', "Yes, I'm working in this school"),
    
    // School's bank account
    'iban_ecole' => env('IBANECOLE', 'BE34 1096 6778 2290'),
    // Bank account's titular
    'iban_titulaire' => env('IBANTITULAIRE', 'THESIS ASBL'),

    // Levels (colors corresponding)
    'levels' => [
        "green" => ["bg" => "bg-shamrock", "text" => "text-bleuis"],
        "blue" => ["bg" => "bg-bleuis", "text" => "text-fantomis"],
        "yellow" => ["bg" => "bg-orangis", "text" => "text-fantomis"],
        "red" => ["bg" => "bg-rougis", "text" => "text-fantomis"]
    ],

    // Tawk.to
    'tawk_show' => env('TAWKSHOW', false),
    'tawk_show_guest' => env('TAWKSHOWGUEST', false),
    'tawk_src' => env('TAWKSRC', 'https://embed.tawk.to/012345678901234567890123/default'),
    ];
